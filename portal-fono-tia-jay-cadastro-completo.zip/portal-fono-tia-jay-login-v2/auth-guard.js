(function(){
  "use strict";
  document.documentElement.classList.add("auth-checking");

  function loginUrl(reason){
    const current = window.location.pathname + window.location.search + window.location.hash;
    const base = new URL("../login.html", window.location.href);
    base.searchParams.set("next", current);
    if (reason) base.searchParams.set("erro", reason);
    return base.href;
  }

  function redirect(reason){
    window.location.replace(loginUrl(reason));
  }

  async function protect(){
    try {
      if (!window.portalSupabase) throw new Error("supabase-unavailable");
      const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), 12000));
      const request = window.portalSupabase.auth.getUser();
      const result = await Promise.race([request, timeout]);
      if (result.error || !result.data || !result.data.user) {
        redirect("sessao");
        return;
      }
      document.documentElement.classList.remove("auth-checking");
      window.portalSupabase.auth.onAuthStateChange(function(event){
        if (event === "SIGNED_OUT") redirect("sessao");
      });
    } catch (error) {
      redirect("conexao");
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", protect, { once: true });
  } else {
    protect();
  }
})();
