const CACHE_NAME = "portal-fono-v6-anamnese-segura";
const PUBLIC_ASSETS = [
  "./", "./index.html", "./login.html", "./reset-password.html",
  "./auth-config.js", "./auth-guard.js", "./logo.png",
  "./icon-192.png", "./icon-512.png", "./apple-touch-icon.png",
  "./manifest.webmanifest", "./imprimir-figuras/index.html",
  "./jogo-da-boca/index.html", "./melo/index.html", "./nina/index.html",
  "./pipo/index.html", "./prancha-caa/index.html", "./tartaruga/index.html",
  "./trem/index.html", "./zaz/index.html"
];
const PROTECTED = ["/anamnese/", "/fonometrica/", "/pacientes/", "/portage/", "/protocolos/", "/registro/", "/relatorios/"];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(PUBLIC_ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", event => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin) return;
  if (PROTECTED.some(path => url.pathname.includes(path))) {
    event.respondWith(fetch(event.request, { cache: "no-store" }).catch(() => new Response("Conexão necessária para acessar a área profissional.", {status: 503, headers:{"Content-Type":"text/plain; charset=utf-8"}})));
    return;
  }
  event.respondWith(fetch(event.request).then(response => {
    if(response && response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(cache=>cache.put(event.request,copy));}
    return response;
  }).catch(() => caches.match(event.request).then(r => r || caches.match("./index.html"))));
});
