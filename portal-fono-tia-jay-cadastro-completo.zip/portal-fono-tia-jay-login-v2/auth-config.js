(function(){
  "use strict";
  const SUPABASE_URL = "https://drfbhmrfbqxhtszygowz.supabase.co";
  const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_xUIkRn7Y4pOfwLbuC5xZSQ_E-q4iU_v";
  if (!window.supabase || typeof window.supabase.createClient !== "function") {
    console.error("Biblioteca do Supabase não carregou.");
    return;
  }
  window.portalSupabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storageKey: "portal-fono-auth-v1"
    }
  });
})();
